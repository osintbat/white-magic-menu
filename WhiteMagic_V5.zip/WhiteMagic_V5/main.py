#!/usr/bin/env python3
import subprocess
import sys
import os

MODULES = [
    "windows-curses",
]

BUILTIN = [
    "time", "random", "math", "os", "subprocess", "sys",
    "ctypes", "socket", "uuid", "locale", "re", "traceback",
    "datetime", "threading", "io", "platform"
]

def install(package):
    print(f"[*] Installing: {package} ...")
    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", package],
        capture_output=True, text=True
    )
    if result.returncode == 0:
        print(f"[+] {package} installed successfully!")
    else:
        print(f"[!] Error with {package}:")
        print(result.stderr)

def launch_log():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    for root, dirs, files in os.walk(script_dir):
        if "log.py" in files:
            target = os.path.join(root, "log.py")
            subprocess.Popen([sys.executable, target])
            return

def main():
    print("=" * 50)
    print("   WHITE MAGIC - MODULE INSTALLER")
    print("=" * 50)
    print()
    print("[i] Python built-in modules (already available):")
    for m in BUILTIN:
        print(f"    + {m}")
    print()
    print("[i] Installing pip modules...")
    print()
    for module in MODULES:
        install(module)
    print()
    print("=" * 50)
    print("[+] Setup complete!")
    print("    ")
    print("=" * 50)
    print()
    launch_log()
    input("Press ENTER to exit...")

if __name__ == "__main__":
    main()